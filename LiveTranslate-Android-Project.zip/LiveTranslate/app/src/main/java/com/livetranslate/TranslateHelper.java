package com.livetranslate;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TranslateHelper {

    private static final String API_URL = "https://api.anthropic.com/v1/messages";
    private static final String MODEL = "claude-haiku-4-5-20251001"; // Fast + cheap
    private static final ExecutorService executor = Executors.newCachedThreadPool();

    public interface OnResult { void onResult(String text); }
    public interface OnError { void onError(String error); }

    private static final String[] FROM_LANG_NAMES = {
        "auto-detect the language",
        "English",
        "Hindi",
        "Bengali/Bangla",
        "Urdu"
    };

    private static final String[] TO_LANG_PROMPTS = {
        // Hinglish
        "Hinglish — yani Hindi ka matlab rakho but Roman/English script mein likho, " +
        "jaise Indians WhatsApp pe likhte hain. Example: 'Kal milte hain yaar!' " +
        "Bilkul natural aur casual raho. Koi Hindi script mat use karo.",

        // English
        "simple conversational English",

        // Pure Hindi
        "shuddh Hindi, Devanagari script mein (जैसे: कल मिलते हैं!)"
    };

    public static void translate(
        Context context,
        String text,
        int fromLangIndex,
        int toLangIndex,
        OnResult onResult,
        OnError onError
    ) {
        AppPrefs prefs = new AppPrefs(context);
        String apiKey = prefs.getApiKey();

        if (apiKey == null || apiKey.isEmpty()) {
            if (onError != null) onError("API key nahi hai! App mein jaake daalo.");
            return;
        }

        String fromLang = FROM_LANG_NAMES[Math.min(fromLangIndex, FROM_LANG_NAMES.length - 1)];
        String toPrompt = TO_LANG_PROMPTS[Math.min(toLangIndex, TO_LANG_PROMPTS.length - 1)];

        String systemPrompt = "You are a chat message translator. " +
            "Translate the given message to " + toPrompt + ". " +
            "The source language is: " + fromLang + ". " +
            "Return ONLY the translated text. No explanation, no quotes, no preamble.";

        executor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("model", MODEL);
                body.put("max_tokens", 300);
                body.put("system", systemPrompt);

                JSONArray messages = new JSONArray();
                JSONObject userMsg = new JSONObject();
                userMsg.put("role", "user");
                userMsg.put("content", text);
                messages.put(userMsg);
                body.put("messages", messages);

                URL url = new URL(API_URL);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("x-api-key", apiKey);
                conn.setRequestProperty("anthropic-version", "2023-06-01");
                conn.setDoOutput(true);
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(15000);

                OutputStream os = conn.getOutputStream();
                os.write(body.toString().getBytes("UTF-8"));
                os.close();

                int code = conn.getResponseCode();
                BufferedReader reader;

                if (code == 200) {
                    reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                } else {
                    reader = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
                }

                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) sb.append(line);
                reader.close();

                if (code == 200) {
                    JSONObject response = new JSONObject(sb.toString());
                    String result = response
                        .getJSONArray("content")
                        .getJSONObject(0)
                        .getString("text")
                        .trim();

                    new Handler(Looper.getMainLooper()).post(() -> {
                        if (onResult != null) onResult(result);
                    });
                } else {
                    String errorMsg = "HTTP " + code;
                    try {
                        JSONObject err = new JSONObject(sb.toString());
                        errorMsg = err.optString("error", errorMsg);
                    } catch (Exception ignored) {}

                    final String finalError = errorMsg;
                    new Handler(Looper.getMainLooper()).post(() -> {
                        if (onError != null) onError(finalError);
                    });
                }

            } catch (Exception e) {
                final String err = e.getMessage() != null ? e.getMessage() : "Unknown error";
                new Handler(Looper.getMainLooper()).post(() -> {
                    if (onError != null) onError(err);
                });
            }
        });
    }
}
