package com.livetranslate;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Switch switchService;
    private Switch switchAutoTranslate;
    private Button btnFromLang, btnToLang;
    private TextView tvStatus;
    private EditText etApiKey;
    private ImageView ivStatusIcon;
    private LinearLayout layoutLangFrom, layoutLangTo;

    private String[] fromLangs = {"Auto Detect", "English", "Hindi", "Bangla", "Urdu"};
    private String[] toLangs = {"Hinglish", "English", "Hindi (pure)"};
    private int selectedFrom = 0;
    private int selectedTo = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        checkPermissions();
        loadSettings();
        setupListeners();
    }

    private void initViews() {
        switchService = findViewById(R.id.switch_service);
        switchAutoTranslate = findViewById(R.id.switch_auto_translate);
        btnFromLang = findViewById(R.id.btn_from_lang);
        btnToLang = findViewById(R.id.btn_to_lang);
        tvStatus = findViewById(R.id.tv_status);
        etApiKey = findViewById(R.id.et_api_key);
        ivStatusIcon = findViewById(R.id.iv_status_icon);
    }

    private void loadSettings() {
        AppPrefs prefs = new AppPrefs(this);
        selectedFrom = prefs.getFromLang();
        selectedTo = prefs.getToLang();
        etApiKey.setText(prefs.getApiKey());
        switchAutoTranslate.setChecked(prefs.isAutoTranslate());
        updateLangButtons();
    }

    private void setupListeners() {
        // Enable/disable accessibility service
        switchService.setOnCheckedChangeListener((btn, isChecked) -> {
            if (isChecked) {
                openAccessibilitySettings();
            }
        });

        // Auto translate toggle
        switchAutoTranslate.setOnCheckedChangeListener((btn, isChecked) -> {
            new AppPrefs(this).setAutoTranslate(isChecked);
            String msg = isChecked ? "Auto translate ON" : "Auto translate OFF";
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        });

        // From language picker
        btnFromLang.setOnClickListener(v -> {
            new android.app.AlertDialog.Builder(this)
                .setTitle("Kaunsi language se translate karein?")
                .setItems(fromLangs, (dialog, which) -> {
                    selectedFrom = which;
                    new AppPrefs(this).setFromLang(which);
                    updateLangButtons();
                })
                .show();
        });

        // To language picker
        btnToLang.setOnClickListener(v -> {
            new android.app.AlertDialog.Builder(this)
                .setTitle("Kaunsi language mein chahiye?")
                .setItems(toLangs, (dialog, which) -> {
                    selectedTo = which;
                    new AppPrefs(this).setToLang(which);
                    updateLangButtons();
                })
                .show();
        });

        // Save API key
        Button btnSaveKey = findViewById(R.id.btn_save_key);
        btnSaveKey.setOnClickListener(v -> {
            String key = etApiKey.getText().toString().trim();
            if (key.isEmpty()) {
                Toast.makeText(this, "API key daalo pehle!", Toast.LENGTH_SHORT).show();
                return;
            }
            new AppPrefs(this).setApiKey(key);
            Toast.makeText(this, "API key save ho gayi!", Toast.LENGTH_SHORT).show();
        });

        // Overlay permission
        Button btnOverlay = findViewById(R.id.btn_overlay_perm);
        btnOverlay.setOnClickListener(v -> requestOverlayPermission());

        // Test translation
        Button btnTest = findViewById(R.id.btn_test);
        btnTest.setOnClickListener(v -> {
            String key = new AppPrefs(this).getApiKey();
            if (key.isEmpty()) {
                Toast.makeText(this, "Pehle API key daalo!", Toast.LENGTH_SHORT).show();
                return;
            }
            tvStatus.setText("Testing... please wait");
            TranslateHelper.translate(
                this,
                "Hello! How are you doing today?",
                selectedFrom,
                selectedTo,
                result -> runOnUiThread(() -> {
                    tvStatus.setText("Test successful!\nResult: " + result);
                }),
                error -> runOnUiThread(() -> {
                    tvStatus.setText("Error: " + error + "\nAPI key check karo.");
                })
            );
        });
    }

    private void updateLangButtons() {
        btnFromLang.setText(fromLangs[selectedFrom]);
        btnToLang.setText(toLangs[selectedTo]);
    }

    private void checkPermissions() {
        boolean accessibilityOn = isAccessibilityServiceEnabled();
        boolean overlayGranted = Settings.canDrawOverlays(this);

        switchService.setChecked(accessibilityOn);

        if (accessibilityOn && overlayGranted) {
            tvStatus.setText("Sab sahi hai! App ready hai.");
            tvStatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
        } else {
            tvStatus.setText("Permissions chahiye — neeche steps follow karo");
            tvStatus.setTextColor(getResources().getColor(android.R.color.holo_orange_dark));
        }
    }

    private boolean isAccessibilityServiceEnabled() {
        String prefString = Settings.Secure.getString(
            getContentResolver(),
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        );
        return prefString != null && prefString.contains(getPackageName());
    }

    private void openAccessibilitySettings() {
        Toast.makeText(this,
            "LiveTranslate Service ko ON kar do",
            Toast.LENGTH_LONG).show();
        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
    }

    private void requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())
            );
            startActivityForResult(intent, 100);
        } else {
            Toast.makeText(this, "Overlay permission pehle se hai!", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkPermissions();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100) {
            checkPermissions();
        }
    }
}
