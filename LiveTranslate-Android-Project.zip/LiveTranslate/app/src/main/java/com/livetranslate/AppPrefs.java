package com.livetranslate;

import android.content.Context;
import android.content.SharedPreferences;

public class AppPrefs {
    private static final String PREF_NAME = "LiveTranslatePrefs";
    private SharedPreferences prefs;

    public AppPrefs(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public String getApiKey() { return prefs.getString("api_key", ""); }
    public void setApiKey(String key) { prefs.edit().putString("api_key", key).apply(); }

    public int getFromLang() { return prefs.getInt("from_lang", 0); }
    public void setFromLang(int idx) { prefs.edit().putInt("from_lang", idx).apply(); }

    public int getToLang() { return prefs.getInt("to_lang", 0); }
    public void setToLang(int idx) { prefs.edit().putInt("to_lang", idx).apply(); }

    public boolean isAutoTranslate() { return prefs.getBoolean("auto_translate", false); }
    public void setAutoTranslate(boolean val) { prefs.edit().putBoolean("auto_translate", val).apply(); }
}
