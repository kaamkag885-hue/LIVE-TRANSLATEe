package com.livetranslate;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayManager {

    private Context context;
    private WindowManager windowManager;
    private View overlayView;
    private View translateBtnView;
    private Handler handler = new Handler(Looper.getMainLooper());
    private boolean isShowing = false;

    public OverlayManager(Context context) {
        this.context = context;
        this.windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
    }

    private WindowManager.LayoutParams getParams(int width, int height, int gravity) {
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        return new WindowManager.LayoutParams(
            width, height, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        );
    }

    public void showTranslateButton(String originalText, String pkg, Runnable onTap) {
        handler.post(() -> {
            hideAll();

            translateBtnView = LayoutInflater.from(context)
                .inflate(R.layout.overlay_translate_btn, null);

            TextView btnText = translateBtnView.findViewById(R.id.tv_translate_btn);
            String appName = getAppName(pkg);
            btnText.setText("Translate karo (" + appName + ")");

            translateBtnView.setOnClickListener(v -> {
                hideTranslateBtn();
                if (onTap != null) onTap.run();
            });

            ImageButton btnClose = translateBtnView.findViewById(R.id.btn_close_fab);
            btnClose.setOnClickListener(v -> hideTranslateBtn());

            WindowManager.LayoutParams params = getParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL
            );
            params.y = 250;

            try {
                windowManager.addView(translateBtnView, params);
            } catch (Exception e) {
                e.printStackTrace();
            }

            // Auto hide after 5 seconds
            handler.postDelayed(this::hideTranslateBtn, 5000);
        });
    }

    public void showLoading() {
        handler.post(() -> {
            hideOverlay();

            overlayView = LayoutInflater.from(context)
                .inflate(R.layout.overlay_translation, null);

            TextView tvOriginal = overlayView.findViewById(R.id.tv_original);
            TextView tvTranslated = overlayView.findViewById(R.id.tv_translated);
            TextView tvLabel = overlayView.findViewById(R.id.tv_lang_label);

            tvLabel.setText("Translating...");
            tvOriginal.setText("");
            tvTranslated.setText("Claude soch raha hai...");

            ImageButton btnClose = overlayView.findViewById(R.id.btn_close);
            btnClose.setOnClickListener(v -> hideOverlay());

            WindowManager.LayoutParams params = getParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            );
            params.y = 0;

            try {
                windowManager.addView(overlayView, params);
                isShowing = true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public void showTranslation(String original, String translated, String pkg) {
        handler.post(() -> {
            if (overlayView == null) {
                showLoading();
            }

            if (overlayView != null) {
                TextView tvOriginal = overlayView.findViewById(R.id.tv_original);
                TextView tvTranslated = overlayView.findViewById(R.id.tv_translated);
                TextView tvLabel = overlayView.findViewById(R.id.tv_lang_label);

                AppPrefs prefs = new AppPrefs(context);
                String[] toLangs = {"Hinglish", "English", "Hindi"};
                String targetLang = toLangs[Math.min(prefs.getToLang(), toLangs.length - 1)];

                tvLabel.setText(getAppName(pkg) + " → " + targetLang);
                tvOriginal.setText(original);
                tvTranslated.setText(translated);
            }

            // Auto hide after 8 seconds
            handler.postDelayed(this::hideOverlay, 8000);
        });
    }

    public void showError(String error) {
        handler.post(() -> {
            if (overlayView != null) {
                TextView tvTranslated = overlayView.findViewById(R.id.tv_translated);
                if (tvTranslated != null) {
                    tvTranslated.setText(error);
                    tvTranslated.setTextColor(Color.parseColor("#FF4444"));
                }
            }
        });
    }

    private String getAppName(String pkg) {
        switch (pkg) {
            case "com.whatsapp": return "WhatsApp";
            case "com.instagram.android": return "Instagram";
            case "com.snapchat.android": return "Snapchat";
            case "com.facebook.katana": return "Facebook";
            case "com.facebook.messenger": return "Messenger";
            default: return "App";
        }
    }

    public void hideOverlay() {
        handler.post(() -> {
            if (overlayView != null) {
                try {
                    windowManager.removeView(overlayView);
                } catch (Exception e) {}
                overlayView = null;
                isShowing = false;
            }
        });
    }

    public void hideTranslateBtn() {
        handler.post(() -> {
            if (translateBtnView != null) {
                try {
                    windowManager.removeView(translateBtnView);
                } catch (Exception e) {}
                translateBtnView = null;
            }
        });
    }

    public void hideAll() {
        hideOverlay();
        hideTranslateBtn();
    }
}
