package com.livetranslate;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.graphics.Rect;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class TranslateAccessibilityService extends AccessibilityService {

    private OverlayManager overlayManager;
    private Set<String> processedMessages = new HashSet<>();
    private String lastPackage = "";

    // WhatsApp message node IDs
    private static final String WA_MSG_ID = "com.whatsapp:id/message_text";
    private static final String IG_MSG_ID = "com.instagram.android:id/direct_text_message_text_view";
    private static final String SNAP_MSG_ID = "com.snapchat.android:id/chat_input_text_field";
    private static final String FB_MSG_ID = "com.facebook.katana:id/message_text";
    private static final String FBM_MSG_ID = "com.facebook.messenger:id/message_text";

    @Override
    public void onCreate() {
        super.onCreate();
        overlayManager = new OverlayManager(this);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;

        String pkg = String.valueOf(event.getPackageName());
        lastPackage = pkg;

        int eventType = event.getEventType();

        if (eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
            eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {

            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null) return;

            List<String> messages = extractMessages(root, pkg);
            processNewMessages(messages, pkg);
            root.recycle();
        }
    }

    private List<String> extractMessages(AccessibilityNodeInfo root, String pkg) {
        List<String> messages = new ArrayList<>();

        String[] msgIds = getMsgIdsForPackage(pkg);
        for (String msgId : msgIds) {
            List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByViewId(msgId);
            if (nodes != null) {
                for (AccessibilityNodeInfo node : nodes) {
                    if (node.getText() != null) {
                        String text = node.getText().toString().trim();
                        if (!text.isEmpty() && text.length() > 2) {
                            messages.add(text);
                        }
                    }
                }
            }
        }

        // Fallback: scan all text nodes
        if (messages.isEmpty()) {
            collectTextNodes(root, messages, pkg);
        }

        return messages;
    }

    private String[] getMsgIdsForPackage(String pkg) {
        switch (pkg) {
            case "com.whatsapp": return new String[]{WA_MSG_ID};
            case "com.instagram.android": return new String[]{IG_MSG_ID};
            case "com.facebook.katana": return new String[]{FB_MSG_ID};
            case "com.facebook.messenger": return new String[]{FBM_MSG_ID};
            default: return new String[]{};
        }
    }

    private void collectTextNodes(AccessibilityNodeInfo node, List<String> out, String pkg) {
        if (node == null) return;
        if (node.getText() != null) {
            String text = node.getText().toString().trim();
            // Filter out UI labels, only get message-like text
            if (text.length() > 5 && text.length() < 1000 &&
                !text.equals("Type a message") &&
                !text.equals("Message") &&
                !text.contains("ago") &&
                !looksLikeUILabel(text)) {
                out.add(text);
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            collectTextNodes(node.getChild(i), out, pkg);
        }
    }

    private boolean looksLikeUILabel(String text) {
        String lower = text.toLowerCase();
        return lower.equals("send") || lower.equals("reply") || lower.equals("react") ||
               lower.equals("home") || lower.equals("search") || lower.equals("back") ||
               lower.length() < 3;
    }

    private void processNewMessages(List<String> messages, String pkg) {
        AppPrefs prefs = new AppPrefs(this);
        boolean autoTranslate = prefs.isAutoTranslate();

        for (String msg : messages) {
            if (!processedMessages.contains(msg)) {
                processedMessages.add(msg);

                // Keep set small
                if (processedMessages.size() > 100) {
                    processedMessages.clear();
                }

                if (autoTranslate) {
                    // Auto translate and show overlay
                    translateAndShow(msg, pkg, prefs);
                } else {
                    // Show tap-to-translate button
                    overlayManager.showTranslateButton(msg, pkg, () -> {
                        translateAndShow(msg, pkg, prefs);
                    });
                }
            }
        }
    }

    private void translateAndShow(String msg, String pkg, AppPrefs prefs) {
        overlayManager.showLoading();

        TranslateHelper.translate(
            this,
            msg,
            prefs.getFromLang(),
            prefs.getToLang(),
            result -> {
                overlayManager.showTranslation(msg, result, pkg);
            },
            error -> {
                overlayManager.showError("Translation fail hua: " + error);
            }
        );
    }

    @Override
    public void onInterrupt() {
        if (overlayManager != null) {
            overlayManager.hideAll();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (overlayManager != null) {
            overlayManager.hideAll();
        }
    }
}
