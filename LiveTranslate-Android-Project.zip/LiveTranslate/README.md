# LiveTranslate — WhatsApp & Instagram Live Translator

## Kya hai yeh app?
Yeh ek Android app hai jo WhatsApp, Instagram, Snapchat aur Facebook ke messages ko **real-time Hinglish** mein translate karta hai — bina app band kiye!

---

## APK Kaise Banayein? (Free, Sirf GitHub chahiye)

### Step 1 — GitHub Account Banao
- [github.com](https://github.com) pe jaao
- "Sign up" karo (free hai)

### Step 2 — Yeh Folder Upload Karo
- GitHub pe "New Repository" banao
- Naam do: `LiveTranslate`
- **Upload files** click karo
- Saara folder drag-and-drop karo
- "Commit changes" click karo

### Step 3 — APK Automatic Banega!
- Repository mein "Actions" tab pe jaao
- "Build APK" workflow dikh raha hoga
- 3-5 minute wait karo
- "Artifacts" section mein `LiveTranslate-debug.apk` download karo!

---

## App Setup Kaise Karein?

### Step 1 — Anthropic API Key Lo (Free)
1. [console.anthropic.com](https://console.anthropic.com) pe jaao
2. Account banao (free credits milte hain)
3. "API Keys" → "Create Key"
4. Key copy karo (sk-ant-... se shuru hoga)

### Step 2 — APK Install Karo
1. Phone mein "Unknown sources" allow karo
   - Settings → Security → Unknown Sources → ON
2. APK install karo

### Step 3 — App Configure Karo
1. App kholo
2. API Key daalo aur "Save karo" press karo
3. "Test" karke dekho kaam karta hai ya nahi
4. Language set karo (default: Auto → Hinglish)

### Step 4 — Permissions Do
1. **Overlay Permission** → "Allow" karo
2. **Accessibility Service** → Switch ON karo → Settings mein "LiveTranslate" dhundho → ON karo

### Step 5 — Use Karo!
- WhatsApp ya Instagram kholo
- Koi message aaye toh neeche purple button dikhega
- **"Translate karo"** press karo
- Hinglish translation aayega!

---

## Supported Apps
| App | Status |
|-----|--------|
| WhatsApp | ✅ Full support |
| Instagram DM | ✅ Full support |
| Facebook | ✅ Full support |
| Messenger | ✅ Full support |
| Snapchat | ⚠️ Limited (security restrictions) |

## Language Pairs
- English → Hinglish
- Hindi → Hinglish  
- Bangla → Hinglish
- Urdu → Hinglish
- Kuch bhi → English
- Kuch bhi → Pure Hindi

## Privacy
- Messages Claude API ko bheje jaate hain translate karne ke liye
- Koi data local save nahi hota
- Anthropic ki privacy policy apply hoti hai

---

## Troubleshooting

**Translation nahi ho raha?**
→ API key check karo — "Test" button dabao

**Bubble nahi dikh raha?**
→ Overlay permission check karo

**Accessibility service band ho jaata hai?**
→ Battery optimization mein LiveTranslate ko exempt karo:
Settings → Battery → App optimization → LiveTranslate → Don't optimize

---

*Made with Claude AI*
